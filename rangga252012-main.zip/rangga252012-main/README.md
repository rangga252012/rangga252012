- 👋 Hi, I’m @rangga252012
- 👀 I’m interested in with AI
- ⚡ Fun fact: nothing is eternal in this world

<!---
rangga252012/rangga252012 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
